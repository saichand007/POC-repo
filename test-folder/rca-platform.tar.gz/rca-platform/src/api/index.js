import apiClient from './client'

// ─────────────────────────────────────────────────────────────────────────────
// Files API
// ─────────────────────────────────────────────────────────────────────────────
export const filesApi = {
  /** GET /files — list all files with pagination */
  getAll: (params = {}) =>
    apiClient.get('/files', { params }).then((r) => r.data),

  /** GET /files/:id */
  getById: (fileId) =>
    apiClient.get(`/files/${fileId}`).then((r) => r.data),

  /** POST /files/upload — multipart form upload */
  upload: (formData, onProgress) =>
    apiClient.post('/files/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
      onUploadProgress: (event) => {
        if (onProgress && event.total) {
          onProgress(Math.round((event.loaded * 100) / event.total))
        }
      },
    }).then((r) => r.data),

  /** GET /files/:id/download — blob */
  download: (fileId) =>
    apiClient.get(`/files/${fileId}/download`, { responseType: 'blob' }).then((r) => r.data),

  /** GET /files/:id/export — CSV blob */
  exportCsv: (fileId) =>
    apiClient.get(`/files/${fileId}/export`, { responseType: 'blob' }).then((r) => r.data),
}

// ─────────────────────────────────────────────────────────────────────────────
// Categories API
// ─────────────────────────────────────────────────────────────────────────────
export const categoriesApi = {
  /** GET /files/:id/categories */
  getByFile: (fileId) =>
    apiClient.get(`/files/${fileId}/categories`).then((r) => r.data),

  /** POST /files/:id/categories/:category/approve — bulk approve */
  approveAll: (fileId, category, payload) =>
    apiClient
      .post(`/files/${fileId}/categories/${encodeURIComponent(category)}/approve`, payload)
      .then((r) => r.data),
}

// ─────────────────────────────────────────────────────────────────────────────
// Errors API
// ─────────────────────────────────────────────────────────────────────────────
export const errorsApi = {
  /**
   * GET /files/:id/errors
   * params: { category?, status?, search?, page, pageSize, sortBy, sortOrder }
   */
  getByFile: (fileId, params = {}) =>
    apiClient.get(`/files/${fileId}/errors`, { params }).then((r) => r.data),

  /** PATCH /errors/:id/approve */
  approve: (errorId, payload = {}) =>
    apiClient.patch(`/errors/${errorId}/approve`, payload).then((r) => r.data),

  /** PATCH /errors/:id/reject */
  reject: (errorId, payload = {}) =>
    apiClient.patch(`/errors/${errorId}/reject`, payload).then((r) => r.data),

  /** PATCH /errors/:id/correct */
  correct: (errorId, payload) =>
    apiClient.patch(`/errors/${errorId}/correct`, payload).then((r) => r.data),

  /** PATCH /errors/bulk — bulk status update */
  bulkUpdate: (payload) =>
    apiClient.patch('/errors/bulk', payload).then((r) => r.data),
}
